package juego;

import javax.swing.JPanel;

public class Sefiroto extends Personaje{
	
	private String sentido;
	private int salud,escudo,arma;
	
	//Llamamos al padre para a�adirle los atributos de nuestro villano
	Sefiroto(JPanel MiJ,int s,int e,int a){
		super(MiJ);
		this.arma=a;
		this.salud=s;
		this.escudo=e;
		
		
	}
	//A�adimos los atributos de sefirot
	public int getSalud() {
		return salud;
	}
	public int getEscudo() {
		return escudo;
	}
	public int getArma() {
		return arma;
	}
	public void setSalud(int s) {
		salud=s;
	}
	public void setEscudo(int e) {
		escudo=e;
	}
	public void setArma(int a) {
		arma=a;
	}
	
	Sefiroto(JPanel MiJ,int x,int y){
		super(MiJ); //Llamada al padre para el movimiento
		this.X=x;
		this.Y=y;
		this.sentido="ESTE";
	}
	
	public void movimientoSefirot() {
		if(this.X<0) {
			this.sentido="ESTE";
			this.X=this.X+10;
			this.setDireccion("src/juego/imagenes/derecha_sefi.png");
		}
		else if(this.X>this.getPanel().getWidth()-100) {
			this.sentido="OESTE";
			this.X=this.X-10;
			this.setDireccion("src/juego/imagenes/izquierda_sefi.png");
		}
		else if(this.sentido.equals("ESTE")) {
			this.X=this.X+10;
			this.setDireccion("src/juego/imagenes/derecha_sefi.png");
		}
		else if(this.sentido.equals("OESTE")) {
			this.X=this.X-10;
			this.setDireccion("src/juego/imagenes/izquierda_sefi.png");
		}
	}
	

}
