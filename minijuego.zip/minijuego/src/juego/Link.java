package juego;

import javax.swing.JPanel;

public class Link extends Personaje {
	
	private int salud;
	private int escudo;
	private int arma;
	
	Link(JPanel MiJ,int s,int e,int a){
		super(MiJ);
		salud=s;
		escudo=e;
		arma=a;
	}
	
	public int getSalud() {
		return salud;
	}
	public int getEscudo() {
		return escudo;
	}
	public int getArma() {
		return arma;
	}
	public void setSalud(int s) {
		salud=s;
	}
	public void setEscudo(int e) {
		escudo=e;
	}
	public void setArma(int a) {
		arma=a;
	}
	

	
}
