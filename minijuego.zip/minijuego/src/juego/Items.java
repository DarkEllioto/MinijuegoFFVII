package juego;

import javax.swing.JPanel;

public class Items {
	
	 
		protected int X,Y;
		protected String PosicionEspada,PosicionCura,PosicionEscudo;
		
		private JPanel MiJJJ;

		Items(JPanel MiJJ) {
			X = 0;
			Y = 0;
			MiJJJ=MiJJ;
		}
		
		public JPanel getPanel() {
			return MiJJJ;
		}

		public String getPosicionEscudo() {
			return this.PosicionEscudo;
		}
		public void setPosicionEscudo(String posicion) {
			this.PosicionEscudo=posicion;
		}
		
		
		public String getPosicionCura() {
			return this.PosicionCura;
		}
		public void setPosicionCura(String posicion) {
			this.PosicionCura=posicion;
		}
		
		public String getPosicionEspada() {
			return this.PosicionEspada;
		}
		public void setPosicionEspada(String posicion) {
			this.PosicionEspada=posicion;
		}
		
		
		
	
		public void setCoordX(int x) {
			this.X=x;
		}
		public void setCoordY(int y) {
			this.Y=y;
		}
	
	
	
		public int CoordX() {
			return this.X;
		
		}
		public int CoordY() {
			return this.Y;
		}

}
