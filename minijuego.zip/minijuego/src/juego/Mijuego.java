package juego;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Timer;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.File;
import java.util.Random;

import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.DataLine;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import java.awt.Color;

public class Mijuego extends JFrame {
	
	private JPanel contentPane;
	
	//Creamos el objeto que da vida al mo�eco
	
	Link player;

	Items objeto;
	
	Timer reloj;

	
	
	Principal Reinicio=new Principal();
	
	/**
	 * Create the frame.
	 * @param sonido 
	 */
	
	public Mijuego(Clip sonido) {
		setTitle("Final Fantasy VII Remake");
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(750, 560, 850, 611);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.GRAY);
		contentPane.add(panel, BorderLayout.CENTER);
		
		player=new Link(panel,100,0,0);
		
		//Le damos vida a nuestro villano
		
		Sefiroto sefirot=new Sefiroto(panel,80,130);
		Fantasma ghost= new Fantasma(panel,100,100);
		
		BustedSword espada=new BustedSword(panel,55,280);
		Escudo escudo= new Escudo(panel,240,280);
		Curaga cura=new Curaga(panel,400,50);
		
		Chocobo chocobito=new Chocobo(panel,160,200);
		
		JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setIcon(new ImageIcon(Mijuego.class.getResource("/juego/imagenes/fondo(2).jpg")));
		panel.add(lblNewLabel_3);
		
		JPanel panel_1 = new JPanel();
		contentPane.add(panel_1, BorderLayout.EAST);
		
		JLabel lblNewLabel = new JLabel("Salud: "+player.getSalud());
		
		JLabel lblNewLabel_1 = new JLabel("Escudo: "+player.getEscudo());
		
		JLabel lblNewLabel_2 = new JLabel("Arma: "+ player.getArma());
		GroupLayout gl_panel_1 = new GroupLayout(panel_1);
		gl_panel_1.setHorizontalGroup(
			gl_panel_1.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_1.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_panel_1.createParallelGroup(Alignment.LEADING)
						.addComponent(lblNewLabel)
						.addComponent(lblNewLabel_1)
						.addComponent(lblNewLabel_2))
					.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
		);
		gl_panel_1.setVerticalGroup(
			gl_panel_1.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_1.createSequentialGroup()
					.addContainerGap()
					.addComponent(lblNewLabel)
					.addGap(39)
					.addComponent(lblNewLabel_1)
					.addGap(52)
					.addComponent(lblNewLabel_2)
					.addContainerGap(107, Short.MAX_VALUE))
		);
		panel_1.setLayout(gl_panel_1);
		
		addKeyListener(new KeyAdapter() {
			//Capturamos el movimiento de nuestro personaje
			public void keyPressed(KeyEvent e) {
				
				System.out.println("X-->"+player.CoordX()+",Y-->"+player.CoordY());
				System.out.println(panel.getHeight());
				
				int x,y;
				String Direc="src/juego/izquierda.png";
				x=player.CoordX();
				y=player.CoordY();
				System.out.println("x-->"+x+",y-->"+y);
				
				
				switch(e.getKeyCode()) {
				case KeyEvent.VK_LEFT:
					if(player.CoordX()>0) {
						player.setCoordX(player.CoordX()-10);
						player.setDireccion("src/juego/imagenes/izquierda.png");
					}
					break;
				case KeyEvent.VK_RIGHT:
					if(player.CoordX()<(panel.getWidth()-50)) {
						player.setCoordX(player.CoordX()+10);
						player.setDireccion("src/juego/imagenes/derecha.png");
					}
					break;
				case KeyEvent.VK_UP:
					if(player.CoordY()>0) {
						player.setCoordY(player.CoordY()-10);
						player.setDireccion("src/juego/imagenes/arriba.png");
					}
					break;
				case KeyEvent.VK_DOWN:
				if(player.CoordY()<(panel.getWidth()-250)){	
					player.setCoordY(player.CoordY()+10);
					player.setDireccion("src/juego/imagenes/abajo.png");
				}
					break;
					
				}
				
			}
		});
		
		
		
		reloj= new Timer(100,new ActionListener(){
			int contTiempo;
			int contMuertes=0;
				public void actionPerformed(ActionEvent e) {
					 
					
					
					//Posicionamiento
					contTiempo=(contTiempo+reloj.getDelay())%5000;
						//System.out.println(contTiempo);
					ghost.getPanel().update(panel.getGraphics());
					player.getPanel().update(panel.getGraphics());
					
					sefirot.getPanel().update(panel.getGraphics());
					player.getPanel().update(panel.getGraphics());
					
					chocobito.getPanel().update(panel.getGraphics());
					player.getPanel().update(panel.getGraphics());
					
					//Actualizamos nuestro personaje
					ImageIcon MiImagen= new ImageIcon(player.getDireccion());
					panel.getGraphics().drawImage(MiImagen.getImage(),player.CoordX(),player.CoordY(),panel);
					
					//Actualizamos a Fantasma
					if (contTiempo==0) {
						ghost.setVisible();
						Random r = new Random();
						int valorX = r.nextInt(650);
						int valorY = r.nextInt(460);
						ghost.setCoordX(valorX);
						ghost.setCoordY(valorY);
						System.out.println("Cambio");
					}
					
					
					//Actualizamos a Sefirot
					if (ghost.getVisible()==0) {
						ghost.movimientoFantasma();
						ImageIcon ImagenFantasma = new ImageIcon(ghost.getDireccion());
						panel.getGraphics().drawImage(ImagenFantasma.getImage(), ghost.CoordX(),ghost.CoordY(), panel);
						
					}
					
					sefirot.movimientoSefirot();
					ImageIcon ImagenSefirot=new ImageIcon(sefirot.getDireccion());
					panel.getGraphics().drawImage(ImagenSefirot.getImage(),sefirot.CoordX(),sefirot.CoordY(),panel);
					
					chocobito.movimientoChocobo();
					ImageIcon ImagenChocobito=new ImageIcon(chocobito.getDireccion());
					panel.getGraphics().drawImage(ImagenChocobito.getImage(),chocobito.CoordX(),chocobito.CoordY(),panel);
					
					//Posicionamos los objetos que nos dan beneficios
					espada.posicionEspada();
					ImageIcon Espada= new ImageIcon(espada.getPosicionEspada());
					panel.getGraphics().drawImage(Espada.getImage(),espada.CoordX(),espada.CoordY(),panel);
					
					escudo.posicionEscudo();
					ImageIcon Escudete= new ImageIcon(escudo.getPosicionEscudo());
					panel.getGraphics().drawImage(Escudete.getImage(),escudo.CoordX(),escudo.CoordY(),panel);
					
					cura.posicionCuraga();
					ImageIcon Curacion= new ImageIcon(cura.getPosicionCura());
					panel.getGraphics().drawImage(Curacion.getImage(),cura.CoordX(),cura.CoordY(),panel);
					
					
					//Colisi�n con los personajes
					int hiddenBox=35;	//Variable creada para regular el tama�o de la caja oculta
					if ((player.CoordX() >= sefirot.CoordX()-hiddenBox && player.CoordX() <= sefirot.CoordX()+hiddenBox) 
							&& ((player.CoordY() >= sefirot.CoordY()-hiddenBox && player.CoordY() <= sefirot.CoordY()+hiddenBox))){
							
						System.out.println("�Cloud  est� tocando a sefirot!");
							
							if(player.getArma()>0) {
								sefirot.setCoordX(900);
								sefirot.setCoordY(900);
								contMuertes+=1;
								}
							else if(player.getEscudo() <= 0) {
								player.setSalud(player.getSalud()-5);
								lblNewLabel.setText("Salud: " + player.getSalud());
							}
							else if(player.getEscudo()>0) {
								player.setEscudo(player.getEscudo()-5);
								lblNewLabel_1.setText("Escudo: " + player.getEscudo());
							}
							if(player.getSalud() <= 0) {
								sonido.stop();
								reloj.stop();
								dispose();
								Reinicio.setVisible(true);
							}
					}
					
					int hiddenBox6=45;	//Variable creada para regular el tama�o de la caja oculta
					if ((player.CoordX() >= ghost.CoordX()-hiddenBox6 && player.CoordX() <= ghost.CoordX()+hiddenBox6) 
							&& ((player.CoordY() >= ghost.CoordY()-hiddenBox6 && player.CoordY() <= ghost.CoordY()+hiddenBox6))){
							
						System.out.println("�Cloud  est� tocando a Fantasma!");
						
						
							if(player.getArma()>0) {
								ghost.setCoordX(900);
								ghost.setCoordY(900);
								contTiempo=1;
								contMuertes+=1;
								}
							else if(player.getEscudo() <= 0) {
								player.setSalud(player.getSalud()-5);
								lblNewLabel.setText("Salud: " + player.getSalud());
							}
							else if(player.getEscudo()>0) {
								player.setEscudo(player.getEscudo()-5);
								lblNewLabel_1.setText("Escudo: " + player.getEscudo());
							}
							if(player.getSalud() <= 0) {
								
								sonido.stop();
								reloj.stop();
								dispose();
								Reinicio.setVisible(true);
								
							}
					}
					
					
					//Colision Chocobo
					int hiddenBox2=40;	//Variable creada para regular el tama�o de la caja oculta
					if ((player.CoordX() >= chocobito.CoordX()-hiddenBox2 && player.CoordX() <= chocobito.CoordX()+hiddenBox2) 
							&& ((player.CoordY() >= chocobito.CoordY()-hiddenBox2 && player.CoordY() <= chocobito.CoordY()+hiddenBox2))){
							
						System.out.println("�Cloud  est� tocando a chocobito!");
						
						if(player.getArma()>0) {
							chocobito.setCoordX(900);
							chocobito.setCoordY(900);
							contMuertes+=1;
							}
						else if(player.getEscudo() <= 0) {
							player.setSalud(player.getSalud()-3);
							lblNewLabel.setText("Salud: " + player.getSalud());
						}
						else if(player.getEscudo()>0) {
							player.setEscudo(player.getEscudo()-2);
							lblNewLabel_1.setText("Escudo: " + player.getEscudo());
						}
						if(player.getSalud() <= 0) {
							
							sonido.stop();
							reloj.stop();
							dispose();
							Reinicio.setVisible(true);
							
							
						}
						
					}
					
					//A�adimos da�o al arma
					int hiddenBox3=25;	//Variable creada para regular el tama�o de la caja oculta
					if ((player.CoordX() >= espada.CoordX()-hiddenBox3 && player.CoordX() <= espada.CoordX()+hiddenBox3) 
							&& ((player.CoordY() >= espada.CoordY()-hiddenBox3 && player.CoordY() <= espada.CoordY()+hiddenBox3))){
							
						System.out.println("�Cloud ha cogido un arma!");
						
							if(player.getArma() <= 0) {
								player.setArma(player.getArma()+110);
								lblNewLabel_2.setText("arma: "+player.getArma());
								espada.setCoordX(900);
								espada.setCoordY(900);
								
							}
							
					}
					//A�adimos escudo
					int hiddenBox4=25;	//Variable creada para regular el tama�o de la caja oculta
					if ((player.CoordX() >= escudo.CoordX()-hiddenBox4 && player.CoordX() <= escudo.CoordX()+hiddenBox4) 
							&& ((player.CoordY() >= escudo.CoordY()-hiddenBox4 && player.CoordY() <= escudo.CoordY()+hiddenBox4))){
							
						System.out.println("�Cloud ha cogido un escudo!");
						
							if(player.getEscudo() <= 0) {
								player.setEscudo(player.getEscudo()+110);
								lblNewLabel_1.setText("Escudo: "+player.getEscudo());
								escudo.setCoordX(900);
								escudo.setCoordY(900);
								
							}
							
					}
					
					//A�adimos salud
					int hiddenBox5=35;	//Variable creada para regular el tama�o de la caja oculta
					if ((player.CoordX() >= cura.CoordX()-hiddenBox5 && player.CoordX() <= cura.CoordX()+hiddenBox5) 
							&& ((player.CoordY() >= cura.CoordY()-hiddenBox5 && player.CoordY() <= cura.CoordY()+hiddenBox5))){
							
						System.out.println("�Cloud ha cogido Salud!");
						
							if(player.getSalud() > 0) {
								player.setSalud(player.getSalud()+75);
								lblNewLabel.setText("Salud: "+player.getSalud());
								cura.setCoordX(900);
								cura.setCoordY(900);
								
							}
							
					}
					if(contMuertes==3) {
						System.out.println("Has completado el minijuego");
						System.exit(0);
						
						
					}


				
					
					//Evitamos parpadeos por si nos lo perdemos ;D
					
					panel.getGraphics().drawImage(null,10,80,null);
				}
			});
		reloj.start();
		}


	private ActionListener ActionListener() {
		
		return null;
	}
	

		
	
				
			
	
		
   
}
