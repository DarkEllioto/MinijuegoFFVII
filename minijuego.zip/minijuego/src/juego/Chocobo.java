package juego;

import javax.swing.JPanel;

public class Chocobo extends Personaje{
	
	private String sentido;
	private int salud,cansancio,hambre,sue�o;
	
	Chocobo(JPanel MiJ,int s,int c,int h,int d){
		super(MiJ);
		this.cansancio=c;
		this.salud=s;
		this.hambre=h;
		this.sue�o=d;
	}
	
	public int getSalud() {
		return salud;
	}
	
	public int getCansancio() {
		return cansancio;
	}
	
	public int getHambre() {
		return hambre;
	}
	public int getSue�o() {
		return sue�o;
	}
	
	public void setSalud(int s) {
		this.salud=s;
	}
	public void setHambre(int h) {
		this.hambre=h;
	}
	public void setCansancio(int c) {
		this.cansancio=c;
	}
	public void setSue�o(int d) {
		this.sue�o=d;
	}
	
	Chocobo(JPanel MiJ,int x,int y){
		super(MiJ); //Llamada al padre para el movimiento
		this.X=x;
		this.Y=y;
		this.sentido="SUR";
	}
	
	public void movimientoChocobo() {
		if(this.Y<0) {
			this.sentido="NORTE";
			this.Y=this.Y+10;
			this.setDireccion("src/juego/imagenes/chocobo_abajo.png");
		}
		else if(this.Y>this.getPanel().getWidth()-350) {
			this.sentido="SUR";
			this.Y=this.Y-10;
			this.setDireccion("src/juego/imagenes/chocobo_arriba.png");
		}
		else if(this.sentido.equals("NORTE")) {
			this.Y=this.Y+10;
			this.setDireccion("src/juego/imagenes/chocobo_abajo.png");
		}
		else if(this.sentido.equals("SUR")) {
			this.Y=this.Y-10;
			this.setDireccion("src/juego/imagenes/chocobo_arriba.png");
		}
	}
}
