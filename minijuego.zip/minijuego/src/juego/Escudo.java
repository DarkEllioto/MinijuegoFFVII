package juego;

import javax.swing.JPanel;

public class Escudo extends Items{

private int Escudo;
	
	
	//Llamamos al padre para a�adirle los atributos de nuestro villano
	Escudo(JPanel MiJJ,int a){
		super(MiJJ);
		this.Escudo=110;
		
		
		
	}
	//A�adimos los atributos de sefirot
	
	public int getArma() {
		return Escudo;
	}
	public void setArma(int a) {
		Escudo=a;
	}
	
	Escudo(JPanel MiJJ,int x,int y){
		super(MiJJ); //Llamada al padre para el movimiento
		this.X=x;
		this.Y=y;
		
	}
	
	public void posicionEscudo() {
					this.setPosicionEscudo("src/juego/imagenes/Buster.png");
			}
			
		
}
