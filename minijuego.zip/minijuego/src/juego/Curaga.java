package juego;

import javax.swing.JPanel;

public class Curaga extends Items{

private int cura;
	
	
	//Llamamos al padre para a�adirle los atributos de nuestro villano
	Curaga(JPanel MiJJ,int a){
		super(MiJJ);
		this.cura=110;
		
		
		
	}
	//A�adimos los atributos de sefirot
	
	public int getCura() {
		return cura;
	}
	public void setCura(int a) {
		cura=a;
	}
	
	Curaga(JPanel MiJJ,int x,int y){
		super(MiJJ); //Llamada al padre para el movimiento
		this.X=x;
		this.Y=y;
		
	}
	
	public void posicionCuraga() {
					this.setPosicionCura("src/juego/imagenes/corazon.png");
			}
			

}
