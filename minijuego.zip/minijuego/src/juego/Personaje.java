package juego;

import javax.swing.JPanel;
import javax.swing.ImageIcon;
import java.awt.Graphics;


	public class Personaje {
		protected int X,Y;
		protected String Direccion;
		
		private JPanel MiJP;

	Personaje(JPanel MiJ) {
		X = 0;
		Y = 0;
		MiJP=MiJ;
	}
	
	public String getDireccion() {
		return this.Direccion;
	}
	public void setDireccion(String direccion) {
		this.Direccion=direccion;
	}
	
	public void setCoordX(int x) {
		this.X=x;
	}
	public void setCoordY(int y) {
		this.Y=y;
	}
	
	public JPanel getPanel() {
		return MiJP;
	}

	
	public int CoordX() {
		return this.X;
		
	}
	public int CoordY() {
		return this.Y;
	}

}
