package juego;

import javax.swing.JPanel;

public class BustedSword extends Items{

	
	private int arma;
	
	
	//Llamamos al padre para a�adirle los atributos de nuestro villano
	BustedSword(JPanel MiJJ,int a){
		super(MiJJ);
		this.arma=110;
		
		
		
	}
	//A�adimos los atributos de sefirot
	
	public int getArma() {
		return arma;
	}
	public void setArma(int a) {
		arma=a;
	}
	
	 BustedSword(JPanel MiJJ,int x,int y){
		super(MiJJ); //Llamada al padre para el movimiento
		this.X=x;
		this.Y=y;
		
	}
	
	public void posicionEspada() {
					this.setPosicionEspada("src/juego/imagenes/arma_final.png");
			}
			
		
}
